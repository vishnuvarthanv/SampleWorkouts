﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreApp.Model
{
    public class FreshEnum
    {
        public enum MyFreshEnum { Fruits = 0, Vegitables = 1, Grocerries = 2 }
    }
}
