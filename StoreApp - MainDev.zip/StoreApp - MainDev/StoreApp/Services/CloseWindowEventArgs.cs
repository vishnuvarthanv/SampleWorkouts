﻿namespace StoreApp.Services
{
    public class CloseWindowEventArgs
    {
    }
}